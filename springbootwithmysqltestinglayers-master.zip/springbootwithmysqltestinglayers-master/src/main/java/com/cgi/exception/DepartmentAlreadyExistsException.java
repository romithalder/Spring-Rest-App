package com.cgi.exception;

public class DepartmentAlreadyExistsException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public DepartmentAlreadyExistsException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public DepartmentAlreadyExistsException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
}
